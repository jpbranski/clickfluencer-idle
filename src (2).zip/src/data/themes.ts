// src/data/themes.ts
import { Theme } from '@/types/theme';

export const themes: Theme[] = [
  {
    id: 'dark',
    name: 'Dark',
    displayName: 'Dark',
    description: 'Default stormy slate theme.',
    cost: 0,
    unlocked: true,
    preview: 'linear-gradient(to bottom right, #1b2330, #2b3350)',
    active: true,
    bonusMultiplier: 1.0, // No bonus (default)
    backgroundImage: '/themes/default-bg.webp',
    iconImage: '/themes/default-icon.webp',
  },
  {
    id: 'light',
    name: 'Light',
    displayName: 'Light',
    description: 'Bright material-inspired palette.',
    cost: 0,
    unlocked: false,
    preview: 'linear-gradient(to bottom right, #ffffff, #eaeef5)',
    active: false,
    bonusMultiplier: 1.0, // No bonus
    backgroundImage: '/themes/default-bg.webp',
    iconImage: '/themes/default-icon.webp',
  },
  {
    id: 'night-sky',
    name: 'Night Sky',
    displayName: 'Night Sky',
    description: 'Cool purples and silvers under starlight. +10% follower generation.',
    cost: 5,
    unlocked: false,
    preview: 'linear-gradient(to bottom right, #1b1f3b 0%, #2a2450 50%, #0b0d1e 100%)',
    active: false,
    bonusMultiplier: 1.1, // +10% follower generation
    backgroundImage: '/themes/default-bg.webp',
    iconImage: '/themes/default-icon.webp',
  },
  {
    id: 'touch-grass',
    name: 'Touch Grass',
    displayName: 'Touch Grass',
    description: 'A peaceful palette of greens and sunlight. +8% follower generation.',
    cost: 10,
    unlocked: false,
    preview: 'linear-gradient(to bottom right, #d8f3dc 0%, #b7e4c7 50%, #95d5b2 100%)',
    active: false,
    bonusMultiplier: 1.08, // +8% follower generation
    backgroundImage: '/themes/default-bg.webp',
    iconImage: '/themes/default-icon.webp',
  },
  {
    id: 'terminal',
    name: 'Terminal',
    displayName: 'Terminal',
    description: 'Monokai dark for true hackers. +12% follower generation.',
    cost: 25,
    unlocked: false,
    preview: 'linear-gradient(to bottom right, #2a2b24 0%, #272822 50%, #1e1f1c 100%)',
    active: false,
    bonusMultiplier: 1.12, // +12% follower generation
    backgroundImage: '/themes/default-bg.webp',
    iconImage: '/themes/default-icon.webp',
  },
  {
    id: 'cherry-blossom',
    name: 'Cherry Blossom',
    displayName: 'Cherry Blossom',
    description: 'Soft pinks drifting through spring air. +7% follower generation.',
    cost: 50,
    unlocked: false,
    preview: 'linear-gradient(to bottom right, #fff1f5 0%, #ffd9e5 50%, #ffc1d6 100%)',
    active: false,
    bonusMultiplier: 1.07, // +7% follower generation
    backgroundImage: '/themes/default-bg.webp',
    iconImage: '/themes/default-icon.webp',
  },
  {
    id: 'themeVV',
    name: 'ThemeVV',
    displayName: 'ThemeVV',
    description: 'Largely white and black (like a panda), with red accents like a crayon. +6.9% click power.',
    cost: 69,
    unlocked: false,
    preview: 'linear-gradient(to bottom right, #FFFFFF 0%, #000000 50%, #FF2B2B 100%)',
    active: false,
    bonusMultiplier: 1.0, // No production bonus
    bonusClickPower: 6.9, // +6.9 to base click power
  },
  {
    id: 'nightshade',
    name: 'Nightshade',
    displayName: 'Nightshade',
    description: 'Belladonna tones of violet and green. +15% follower generation.',
    cost: 100,
    unlocked: false,
    preview: 'linear-gradient(to bottom right, #211326 0%, #311b3a 50%, #0c0c0d 100%)',
    active: false,
    bonusMultiplier: 1.15, // +15% follower generation
    backgroundImage: '/themes/default-bg.webp',
    iconImage: '/themes/default-icon.webp',
  },
  {
    id: 'el-blue',
    name: 'EL Blue',
    displayName: 'EL Blue',
    description: 'Inspired by Extra Life\'s heroic blue. +20% follower generation.',
    cost: 500,
    unlocked: false,
    preview: 'linear-gradient(to bottom right, #0a192f 0%, #112240 50%, #0d2742 100%)',
    active: false,
    bonusMultiplier: 1.2, // +20% follower generation
    backgroundImage: '/themes/default-bg.webp',
    iconImage: '/themes/default-icon.webp',
  },
  {
    id: 'gold',
    name: 'Gold',
    displayName: 'Gold',
    description: 'Luxury that shines bright and bold. +25% follower generation.',
    cost: 1000,
    unlocked: false,
    preview: 'linear-gradient(to bottom right, #3a2a10 0%, #6f5215 50%, #d4af37 100%)',
    active: false,
    bonusMultiplier: 1.25, // +25% follower generation
    backgroundImage: '/themes/default-bg.webp',
    iconImage: '/themes/default-icon.webp',
  },
];
