/**
 * actions.ts - Core Gameplay Actions
 *
 * This module contains all game actions that mutate state.
 * Each action is a pure function that takes state and returns new state.
 *
 * Connected to:
 * - state.ts: Reads and mutates game state
 * - engine.ts: Called by game loop and user interactions
 * - prestige.ts: Used for prestige action
 * - UI components: Triggered by user interactions
 *
 * Actions:
 * - clickPost: Manual clicking for followers
 * - buyGenerator: Purchase content generators
 * - buyUpgrade: Purchase permanent upgrades
 * - purchaseTheme: Buy cosmetic themes with awards
 * - applyEvent: Activate random events
 * - tick: Process one game tick (passive generation)
 */

import {
  GameState,
  Upgrade,
  RandomEvent,
  getGeneratorCost,
  getClickPower,
  getFollowersPerSecond,
  shouldUnlockGenerator,
  canAfford,
  canAffordAwards,
  getClickEventMultiplier,
  getCredCacheRate,
  getCredCachePayoutMultiplier,
} from "./state";
import { executePrestige, applyPrestige } from "./prestige";
import {
  getNotorietyGeneratorCost,
  getNotorietyUpgradeCost,
  getNotorietyGainPerSecond,
  getTotalUpkeep,
  getCacheValueBonus,
} from "./logic/notorietyLogic";
import { NOTORIETY_GENERATORS, NOTORIETY_UPGRADES } from "@/data/notoriety";

// ============================================================================
// CONSTANTS
// ============================================================================

export const SHARD_DROP_CHANCE = 0.003; // 0.3% chance per click (changed from 0.03%)
export const BASE_TICK_RATE = 250; // milliseconds between ticks

// ============================================================================
// HELPER FUNCTIONS
// ============================================================================

/**
 * Calculate current award drop rate based on purchased upgrades
 * Base: 0.3%, each Lucky Charm tier adds +0.3%
 * Max with all 4 tiers: 1.5%
 */
export function getAwardDropRate(state: GameState): number {
  let dropRate = SHARD_DROP_CHANCE;

  // Handle Lucky Charm tiered upgrade
  const luckyCharm = state.upgrades.find((u) => u.id === "lucky_charm");
  if (luckyCharm && luckyCharm.tier && luckyCharm.tier > 0) {
    // Add 0.3% per tier
    dropRate += luckyCharm.effect.value * luckyCharm.tier;
  }

  // Also handle old award drop rate upgrades for backwards compatibility
  state.upgrades
    .filter((u) => u.purchased && u.effect.type === "awardDropRate" && u.id !== "lucky_charm")
    .forEach((u) => {
      dropRate += u.effect.value;
    });

  return dropRate;
}

// ============================================================================
// ACTION RESULTS
// ============================================================================

export interface ActionResult {
  success: boolean;
  state: GameState;
  message?: string;
}

export interface ClickResult extends ActionResult {
  credsGained: number;
  awardDropped: boolean;
  credCacheTriggered: boolean;
  credCacheAmount: number;
}

// ============================================================================
// CLICK ACTION
// ============================================================================

/**
 * Execute a manual click
 * - Grants creds based on click power
 * - 0.3%-1.5% chance to drop an award
 * - Small chance to trigger Cred Cache (1-5% of current creds)
 * - Updates statistics
 */
export function clickPost(state: GameState): ClickResult {
  const clickPower = getClickPower(state);
  const eventMultiplier = getClickEventMultiplier(state);
  const credsGained = clickPower * eventMultiplier;

  // Check for award drop (Variable chance based on upgrades)
  const awardDropped = Math.random() < getAwardDropRate(state);

  // Check for Cred Cache drop
  const credCacheRate = getCredCacheRate(state);
  const credCacheTriggered = credCacheRate > 0 && Math.random() < credCacheRate;
  let credCacheAmount = 0;

  if (credCacheTriggered) {
    // Award 1-5% of current total creds
    const percentage = 0.01 + Math.random() * 0.04; // Random between 1% and 5%
    const baseAmount = Math.floor(state.creds * percentage);
    // Apply Notoriety Cache Value boost
    const cacheMultiplier = getCredCachePayoutMultiplier(state);
    credCacheAmount = Math.floor(baseAmount * cacheMultiplier);
  }

  const newState: GameState = {
    ...state,
    creds: state.creds + credsGained + credCacheAmount,
    awards: state.awards + (awardDropped ? 1 : 0),
    stats: {
      ...state.stats,
      totalClicks: state.stats.totalClicks + 1,
      totalCredsEarned: state.stats.totalCredsEarned + credsGained + credCacheAmount,
      awardsEarned: state.stats.awardsEarned + (awardDropped ? 1 : 0),
    },
  };

  return {
    success: true,
    state: newState,
    credsGained,
    awardDropped,
    credCacheTriggered,
    credCacheAmount,
  };
}

// ============================================================================
// GENERATOR ACTIONS
// ============================================================================

/**
 * Purchase a generator (content creation system)
 * - Deducts creds equal to cost
 * - Increments generator count
 * - Updates cost for next purchase
 * - Updates statistics
 */
export function buyGenerator(
  state: GameState,
  generatorId: string,
): ActionResult {
  const generator = state.generators.find((g) => g.id === generatorId);

  if (!generator) {
    return {
      success: false,
      state,
      message: "Generator not found",
    };
  }

  if (!generator.unlocked) {
    return {
      success: false,
      state,
      message: "Generator not unlocked yet",
    };
  }

  const cost = getGeneratorCost(generator);

  if (!canAfford(state.creds, cost)) {
    return {
      success: false,
      state,
      message: "Not enough creds",
    };
  }

  // Update generator count and deduct cost
  const newGenerators = state.generators.map((g) =>
    g.id === generatorId ? { ...g, count: g.count + 1 } : g,
  );

  const newState: GameState = {
    ...state,
    creds: state.creds - cost,
    generators: newGenerators,
    stats: {
      ...state.stats,
      totalGeneratorsPurchased: state.stats.totalGeneratorsPurchased + 1,
    },
  };

  return {
    success: true,
    state: newState,
    message: `Purchased ${generator.name}`,
  };
}

/**
 * Buy multiple generators at once
 * Buys as many as affordable up to the specified count
 */
export function buyGeneratorBulk(
  state: GameState,
  generatorId: string,
  count: number,
): ActionResult {
  let currentState = state;
  let purchased = 0;

  for (let i = 0; i < count; i++) {
    const result = buyGenerator(currentState, generatorId);
    if (!result.success) break;
    currentState = result.state;
    purchased++;
  }

  if (purchased === 0) {
    return {
      success: false,
      state,
      message: "Cannot afford any generators",
    };
  }

  const generator = state.generators.find((g) => g.id === generatorId);
  return {
    success: true,
    state: currentState,
    message: `Purchased ${purchased} ${generator?.name}`,
  };
}

// ============================================================================
// UPGRADE ACTIONS
// ============================================================================

/**
 * Get the current cost of an upgrade (handles scaling for infinite and tiered upgrades)
 */
export function getUpgradeCost(upgrade: Upgrade): number {
  // Handle tiered upgrades (e.g., better_camera)
  if (upgrade.tier !== undefined && upgrade.costMultiplier !== undefined) {
    const currentTier = upgrade.tier || 0;
    return Math.floor(upgrade.cost * Math.pow(upgrade.costMultiplier, currentTier));
  }

  // Handle infinite upgrades (e.g., ai_enhancements)
  if (upgrade.costMultiplier && upgrade.currentLevel !== undefined) {
    // Infinite upgrade - cost scales exponentially
    return Math.floor(upgrade.cost * Math.pow(upgrade.costMultiplier, upgrade.currentLevel));
  }

  // Regular one-time upgrades
  return upgrade.cost;
}

/**
 * Purchase an upgrade
 * - One-time purchase that provides permanent bonuses
 * - For infinite upgrades: can be purchased repeatedly with scaling cost
 * - For tiered upgrades: can be purchased up to maxTier times
 * - Deducts followers equal to current cost
 * - Marks upgrade as purchased (or increments level/tier for progressive)
 */
export function buyUpgrade(state: GameState, upgradeId: string): ActionResult {
  const upgrade = state.upgrades.find((u) => u.id === upgradeId);

  if (!upgrade) {
    return {
      success: false,
      state,
      message: "Upgrade not found",
    };
  }

  // Check if it's a tiered upgrade
  const isTiered = upgrade.tier !== undefined && upgrade.maxTier !== undefined;
  const currentTier = upgrade.tier || 0;

  // Check if tiered upgrade is maxed out
  if (isTiered && upgrade.maxTier && currentTier >= upgrade.maxTier) {
    return {
      success: false,
      state,
      message: "Already maxed out",
    };
  }

  // Check if it's an infinite upgrade
  const isInfinite = upgrade.maxLevel === undefined || (upgrade.maxLevel && (upgrade.currentLevel || 0) < upgrade.maxLevel);

  // For non-infinite, non-tiered upgrades, check if already purchased
  if (!isInfinite && !isTiered && upgrade.purchased) {
    return {
      success: false,
      state,
      message: "Already purchased",
    };
  }

  const currentCost = getUpgradeCost(upgrade);

  if (!canAfford(state.creds, currentCost)) {
    return {
      success: false,
      state,
      message: "Not enough creds",
    };
  }

  const newUpgrades = state.upgrades.map((u) => {
    if (u.id === upgradeId) {
      // Handle tiered upgrades
      if (u.tier !== undefined && u.maxTier !== undefined) {
        const nextTier = (u.tier || 0) + 1;
        return {
          ...u,
          tier: nextTier,
          purchased: nextTier >= u.maxTier, // mark as purchased when maxed
        };
      }

      // Handle infinite upgrades properly
      else if (u.currentLevel !== undefined && u.costMultiplier) {
        const nextLevel = (u.currentLevel || 0) + 1;
        return {
          ...u,
          currentLevel: nextLevel,
          purchased: false, // 🔧 stays buyable forever
        };
      }

      // Handle regular one-time upgrades
      else {
        return { ...u, purchased: true };
      }
    }
    return u;
  });


  const newState: GameState = {
    ...state,
    creds: state.creds - currentCost,
    upgrades: newUpgrades,
    stats: {
      ...state.stats,
      totalUpgradesPurchased: state.stats.totalUpgradesPurchased + 1,
    },
  };

  return {
    success: true,
    state: newState,
    message: `Purchased ${upgrade.name}`,
  };
}

// ============================================================================
// THEME ACTIONS
// ============================================================================

/**
 * Purchase a theme with awards
 * - Unlocks the theme for use
 * - Bonus applies immediately and permanently
 */
export function purchaseTheme(state: GameState, themeId: string): ActionResult {
  const theme = state.themes.find((t) => t.id === themeId);

  if (!theme) {
    return {
      success: false,
      state,
      message: "Theme not found",
    };
  }

  if (theme.unlocked) {
    return {
      success: false,
      state,
      message: "Theme already unlocked",
    };
  }

  if (!canAffordAwards(state.awards, theme.cost)) {
    return {
      success: false,
      state,
      message: "Not enough awards",
    };
  }

  const newThemes = state.themes.map((t) =>
    t.id === themeId ? { ...t, unlocked: true } : t,
  );

  const newState: GameState = {
    ...state,
    awards: state.awards - theme.cost,
    themes: newThemes,
  };

  return {
    success: true,
    state: newState,
    message: `Unlocked ${theme.name}`,
  };
}

/**
 * Activate a theme
 * - Deactivates current theme
 * - Activates selected theme
 * - Theme must be unlocked
 * - Bonus is always active for all unlocked themes (bonuses stack)
 * - Visual theme is applied via useGame hook
 */
export function activateTheme(state: GameState, themeId: string): ActionResult {
  const theme = state.themes.find((t) => t.id === themeId);

  if (!theme) {
    return {
      success: false,
      state,
      message: "Theme not found",
    };
  }

  if (!theme.unlocked) {
    return {
      success: false,
      state,
      message: "Theme not unlocked",
    };
  }

  const newThemes = state.themes.map((t) => ({
    ...t,
    active: t.id === themeId,
  }));

  const newState: GameState = {
    ...state,
    themes: newThemes,
  };

  return {
    success: true,
    state: newState,
    message: `Activated ${theme.name}`,
  };
}

// ============================================================================
// EVENT ACTIONS
// ============================================================================

/**
 * Apply a random event
 * - Adds event to active events
 * - Event expires after duration
 */
export function applyEvent(state: GameState, event: RandomEvent): GameState {
  const eventWithEndTime: RandomEvent = {
    ...event,
    active: true,
    endTime: Date.now() + event.duration,
  };

  return {
    ...state,
    activeEvents: [...state.activeEvents, eventWithEndTime],
  };
}

/**
 * Remove expired events
 * - Checks each active event
 * - Removes events past their endTime
 */
export function removeExpiredEvents(state: GameState): GameState {
  const now = Date.now();
  const activeEvents = state.activeEvents.filter(
    (event) => event.endTime && event.endTime > now,
  );

  return {
    ...state,
    activeEvents,
  };
}


// ============================================================================
// TICK ACTION
// ============================================================================

/**
 * Process one game tick
 * - Generates creds from all generators (minus upkeep)
 * - Generates notoriety from notoriety generators
 * - Unlocks generators based on cred count
 * - Removes expired events
 * - Updates statistics
 */
export function tick(state: GameState, deltaTime: number): GameState {
  const secondsElapsed = deltaTime / 1000;

  // Calculate creds generated this tick
  const credsPerSecond = getFollowersPerSecond(state);

  // Calculate upkeep cost from notoriety generators
  const upkeepPerSecond = getTotalUpkeep(state);

  // Net creds after upkeep
  const netCredsPerSecond = credsPerSecond - upkeepPerSecond;
  const credsGained = netCredsPerSecond * secondsElapsed;

  // Calculate notoriety gain this tick
  const notorietyPerSecond = getNotorietyGainPerSecond(state);
  const notorietyGained = notorietyPerSecond * secondsElapsed;

  // Update generators unlock status
  const newGenerators = state.generators.map((g) => {
    if (shouldUnlockGenerator(g, state.creds)) {
      return { ...g, unlocked: true };
    }
    return g;
  });

  // Remove expired events
  let newState: GameState = {
    ...state,
    creds: state.creds + credsGained,
    notoriety: (state.notoriety || 0) + notorietyGained,
    generators: newGenerators,
    stats: {
      ...state.stats,
      totalCredsEarned: state.stats.totalCredsEarned + Math.max(0, credsGained),
      lastTickTime: Date.now(),
    },
  };

  // Clean up expired events
  newState = removeExpiredEvents(newState);

  return newState;
}

// ============================================================================
// PRESTIGE ACTION
// ============================================================================

/**
 * Execute prestige
 * - Spends Creds to gain prestige points
 * - Awards +10% permanent bonus per point
 * - No longer resets progress
 */
export function prestige(state: GameState): ActionResult {
  const result = executePrestige(state);

  if (!result.success) {
    return {
      success: false,
      state,
      message: result.message,
    };
  }

  const newState = applyPrestige(state, result.prestigeGained, result.credsLost);

  return {
    success: true,
    state: newState,
    message: result.message,
  };
}

// ============================================================================
// NOTORIETY ACTIONS
// ============================================================================

/**
 * Purchase a notoriety generator
 * - Deducts creds equal to cost
 * - Increases generator level by 1
 * - Validates that Creds/s remains above 1 after upkeep
 */
export function buyNotorietyGenerator(
  state: GameState,
  generatorId: string,
): ActionResult {
  const generator = NOTORIETY_GENERATORS.find((g) => g.id === generatorId);

  if (!generator) {
    return {
      success: false,
      state,
      message: "Generator not found",
    };
  }

  const currentLevel = state.notorietyGenerators[generatorId] || 0;
  const cost = getNotorietyGeneratorCost(generator, currentLevel);

  if (!canAfford(state.creds, cost)) {
    return {
      success: false,
      state,
      message: "Not enough Creds",
    };
  }

  const newState: GameState = {
    ...state,
    creds: state.creds - cost,
    notorietyGenerators: {
      ...state.notorietyGenerators,
      [generatorId]: currentLevel + 1,
    },
  };

  return {
    success: true,
    state: newState,
    message: `Purchased ${generator.name}`,
  };
}

/**
 * Purchase a notoriety upgrade
 * - Deducts notoriety equal to cost
 * - Increases upgrade level by 1
 * - Applies upgrade effects
 */
export function buyNotorietyUpgrade(
  state: GameState,
  upgradeId: string,
): ActionResult {
  const upgrade = NOTORIETY_UPGRADES.find((u) => u.id === upgradeId);

  if (!upgrade) {
    return {
      success: false,
      state,
      message: "Upgrade not found",
    };
  }

  const currentLevel = state.notorietyUpgrades[upgradeId] || 0;

  if (currentLevel >= upgrade.cap) {
    return {
      success: false,
      state,
      message: "Max level reached",
    };
  }

  const cost = getNotorietyUpgradeCost(upgrade, currentLevel);

  if (state.notoriety < cost) {
    return {
      success: false,
      state,
      message: "Not enough Notoriety",
    };
  }

  // Handle special instant-effect upgrades like "buy_creds"
  let bonusCreds = 0;
  if (upgradeId === "buy_creds") {
    const credsPerSecond = getFollowersPerSecond(state);
    bonusCreds = credsPerSecond * 30 * 60; // 30 minutes worth
  }

  const newState: GameState = {
    ...state,
    notoriety: state.notoriety - cost,
    creds: state.creds + bonusCreds,
    notorietyUpgrades: {
      ...state.notorietyUpgrades,
      [upgradeId]: currentLevel + 1,
    },
  };

  return {
    success: true,
    state: newState,
    message: `Purchased ${upgrade.name}`,
  };
}

// ============================================================================
// SETTINGS ACTIONS
// ============================================================================

/**
 * Update a setting
 */
export function updateSetting<K extends keyof GameState["settings"]>(
  state: GameState,
  key: K,
  value: GameState["settings"][K],
): GameState {
  return {
    ...state,
    settings: {
      ...state.settings,
      [key]: value,
    },
  };
}
